package com.onlinebanking.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Util.DBUtil;

public class OnlineBankingDao implements IonlineBankingDao{
	@Override
	public String validateUser(long userId, String password) throws OnlineBankingException, SQLException {
		String result = null;
		Connection con = DBUtil.obtainConnection();
		PreparedStatement st;
		int flag = 0;
		try {
			st = con.prepareStatement(IQueryMapper.USER_DETAILS);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
				long id = Long.parseLong(rs.getString(1));
				String pwd = rs.getString(2);
				if(id==userId && password.equals(pwd)){
					flag = 1;
					result=rs.getString(3);
					break;
				}
			}
			if(flag==0){
				result ="fail";
			}
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return result;
	}
	
	
	@Override
	public ArrayList<Long> getAccounts(long userId) throws OnlineBankingException{
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		long user_id=0;
		String pwd=null;
		long account_no=0;
		ArrayList<Long> accounts=new ArrayList<Long>();
		
		try{
			con=DBUtil.obtainConnection();
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.GET_ACCOUNTS);
			st.setLong(1, userId);
	
			rs=st.executeQuery();
		
			if(rs!=null){
				while(rs.next()){
					user_id=rs.getLong(2);
					pwd=rs.getString(3);
					account_no=rs.getLong(1);
					accounts.add(account_no);
				}
			}			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accounts;
	}

	@Override
	public ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException {
		String trans_details=null;
		long accountno = 0;
		long trans_id=0;
		int count=0;
		long amount;
		StringBuilder sb=new StringBuilder();
		ArrayList<OnlineBankingBean> miniStatement = new ArrayList<OnlineBankingBean>();
		try{  
		Connection con=DBUtil.obtainConnection();  
		Statement stmt=con.createStatement();  
		PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.miniStatement);
		long account_no=Long.parseLong(acc_no);
		pmstmt.setLong(1, account_no);
		System.out.println("hello");
		ResultSet rs=pmstmt.executeQuery();
		
		System.out.println("hello");
		
		if(rs!=null){
			while(rs.next()){
				OnlineBankingBean b=new OnlineBankingBean();
				//account=rs.getLong(1);
				trans_details=rs.getString(4);
				System.out.println(trans_details);
				amount=rs.getLong(2);
				System.out.println(amount);
				accountno=rs.getLong(1);
				System.out.println(accountno);
				trans_id=rs.getLong(3);
				System.out.println(trans_id);
				b.setAccountNo(accountno);
				b.setTransactionId(trans_id);
				b.setTransactionAmount(amount);
				b.setTransactionDate(trans_details);
				miniStatement.add(b);
				
				//sb.append(trans_id+"       "+accountno+"           "+amount+"          "+trans_details);
			}
		}
		  
	}
		catch(Exception e){
			//throw new OnlineBankingException("Failed in database Connectivity");
			//System.out.println(e.getMessage()+" hello");
			e.printStackTrace();
		}
// TODO Auto-generated method stub
		return miniStatement;
	}


	@Override
	public boolean getRegistered(OnlineBankingBean userbean)
			throws OnlineBankingException, SQLException {
		boolean result = false;
		try{
			Connection con = DBUtil.obtainConnection();  
		
			PreparedStatement st = con.prepareStatement(IQueryMapper.INSERT_DETAILS);
			st.setLong(1, userbean.getAccountNo());
			st.setLong(2, userbean.getUserId());
			st.setString(3, userbean.getLoginPwd());
			st.setString(4, "What is Your Favourite color");
			st.setString(5, userbean.getColor());
			st.setString(6, userbean.getTransPwd());
			
			int rows = st.executeUpdate();
			if(rows > 0){
				System.out.println("Values inserted successfully");
				result=true;
			}
			else{
				result=false;
				throw new OnlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			}
			catch(Exception e){
				throw new OnlineBankingException("Please Create your Bank Account to opt online Banking");
			}
		
	return result;
	}


	@Override
	public ArrayList<OnlineBankingBean> getdetailedStatement(long acc_no,String fromDate,String toDate) {
		String trans_details=null;
		long accountno = 0;
		long trans_id=0;
		int count=0;
		long amount;
		StringBuilder sb=new StringBuilder();
		ArrayList<OnlineBankingBean> detailedStatement = new ArrayList<OnlineBankingBean>();
		try{  
		Connection con=DBUtil.obtainConnection();  
		Statement stmt=con.createStatement();  
		PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.detailedStatement);
		long account_no=acc_no;
		pmstmt.setLong(1, account_no);
		pmstmt.setString(2, fromDate);
		pmstmt.setString(3, toDate);
		System.out.println("hello");
		ResultSet rs=pmstmt.executeQuery();
		
		System.out.println("hello");
		
		if(rs!=null){
			while(rs.next()){
				OnlineBankingBean b=new OnlineBankingBean();
				//account=rs.getLong(1);
				trans_details=rs.getString(4);
				System.out.println(trans_details);
				amount=rs.getLong(2);
				System.out.println(amount);
				accountno=rs.getLong(1);
				System.out.println(accountno);
				trans_id=rs.getLong(3);
				System.out.println(trans_id);
				b.setAccountNo(accountno);
				b.setTransactionId(trans_id);
				b.setTransactionAmount(amount);
				b.setTransactionDate(trans_details);
				detailedStatement.add(b);
				
				//sb.append(trans_id+"       "+accountno+"           "+amount+"          "+trans_details);
			}
		}
		  
	}
		catch(Exception e){
			//throw new OnlineBankingException("Failed in database Connectivity");
			//System.out.println(e.getMessage()+" hello");
			e.printStackTrace();
		}
// TODO Auto-generated method stub
		return detailedStatement;

	}


	@Override
	public ArrayList<Long> getPayeeAccounts(long uid) {
		Connection con=null;
		PreparedStatement pmstmt=null;
		ResultSet rs=null;
		Statement stmt=null;
		ArrayList<Long> payeeAccounts=new ArrayList<Long>();
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.payeeAccounts);
			pmstmt.setLong(1, uid);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					payeeAccounts.add(rs.getLong(1));
				}
			}
		}
		catch(Exception e){
			
		}
		return payeeAccounts;
	}

}
