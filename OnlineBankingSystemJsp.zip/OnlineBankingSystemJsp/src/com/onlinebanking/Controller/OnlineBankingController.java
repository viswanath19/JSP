package com.onlinebanking.Controller;

import java.awt.print.Printable;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;








import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Service.IonlineBankingService;
import com.onlinebanking.Service.OnlineBankingService;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = null;
		OnlineBankingBean bean = new OnlineBankingBean();
		PrintWriter out = response.getWriter();
		RequestDispatcher rd=null;
		String operation=request.getParameter("action");
		System.out.println("Operation =" + operation);
		//HttpSession session=request.getSession(true);
		IonlineBankingService ibs=new OnlineBankingService();
		ArrayList<Long> accounts=new ArrayList<Long>();
		
		
		if(operation!=null && operation.equalsIgnoreCase("Login")){
			System.out.println("Reached login");
			session = request.getSession(true);
			long userId=Long.parseLong(request.getParameter("userID"));
			String pwd=request.getParameter("pwd");
			try {
				if(userId==12345l && pwd.equals("admin")){
					session.setAttribute("uname", "admin");
					ServletContext context = getServletContext();
					rd = context.getRequestDispatcher("/homeAdmin.jsp");
					rd.include(request, response);
				}
				else{
					String result = ibs.validateUser(userId, pwd);
					if(!result.equals("fail")){
						accounts=ibs.getAccounts(userId);
						session.setAttribute("uname", result);
						session.setAttribute("accounts",accounts);
						session.setAttribute("userId", userId);
						ServletContext context = getServletContext();
						rd = context.getRequestDispatcher("/homeUser.jsp");
						rd.include(request, response);
					}
					else{
						session.setAttribute("uname", "fail");
						//System.out.println("\n\nreached else\n\n");
						ServletContext context = getServletContext();
						rd = context.getRequestDispatcher("/login.jsp");
						rd.include(request, response);
					}
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				ServletContext context = getServletContext();
				rd = context.getRequestDispatcher("/Error.jsp");
				rd.forward(request, response);
			}
			/*
			try{
				accounts=ibs.validateUser(userId,password);
				session.setAttribute("accounts",accounts);
				System.out.println(accounts);
				rd=request.getRequestDispatcher("/home.jsp");
				rd.include(request, response);
			}
			catch(OnlineBankingException e){
				
			}
			*/
		}
		else if(operation!=null&&operation.equalsIgnoreCase("FetchAccounts")){
			String accountDetails=request.getParameter("accounts").toString().replace("[", "").replace("]", "");
			List<String> myList = new ArrayList<String>(Arrays.asList(accountDetails.split(",")));
			System.out.println(accountDetails);
			request.setAttribute("accountDetails", myList);
			rd=request.getRequestDispatcher("/FetchAccounts.jsp");
			rd.include(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("FetchDetailedAccounts")){
			String accountDetails=request.getParameter("accounts").toString().replace("[", "").replace("]", "");
			List<String> myList = new ArrayList<String>(Arrays.asList(accountDetails.split(",")));
			System.out.println(accountDetails);
			request.setAttribute("DetailedaccountDetails", myList);
			rd=request.getRequestDispatcher("/FetchDetailedAccounts.jsp");
			rd.include(request, response);
		}
		else if(operation!=null&&operation.equals("viewDetailedStatement")){
			long accountNo=Long.parseLong(request.getParameter("accountno"));
			request.setAttribute("account", accountNo);
			rd=request.getRequestDispatcher("/DetailedStatement.jsp");
			rd.include(request, response);
		}
		else if(operation!=null&&operation.equals("viewMiniStatement")){
			String acc_no=request.getParameter("accountno");
			try {
				ArrayList<OnlineBankingBean> miniStatement=ibs.getMiniStatement(acc_no);
				System.out.println(miniStatement);
				request.setAttribute("miniStatement", miniStatement);
				rd=request.getRequestDispatcher("/ViewMiniStatement.jsp");
				rd.forward(request, response);
			} catch (OnlineBankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(operation!=null&&operation.equals("GetDetailedStatement")){
			//System.out.println(request.getAttribute("accountNo"));
			//System.out.println(acc_no);
			long acc_no=Long.parseLong(request.getParameter("account"));
			String fromDate=request.getParameter("fromDate");
			String toDate=request.getParameter("toDate");
			
			//System.out.println(date);
				ArrayList<OnlineBankingBean> detailedStatement=ibs.getDetailedStatement(acc_no,fromDate,toDate);
				System.out.println(detailedStatement);
				request.setAttribute("detailedStatement", detailedStatement);
				rd=request.getRequestDispatcher("/ViewDetailedStatement.jsp");
				rd.forward(request, response);
			
			//System.out.println(acc_no);
			//System.out.println(fromDate);
			//System.out.println(toDate);
			
		}
		else if(operation!=null && operation.equals("register")){
			System.out.println("Reached : " + operation);
			try {
				long accNum = Long.parseLong(request.getParameter("accNum"));
				long userId = Long.parseLong(request.getParameter("userId"));
				String pwd = request.getParameter("loginPwd");
				String color = request.getParameter("color");
				String transPwd = request.getParameter("transPwd");
				
				
				bean.setAccountNo(accNum);
				bean.setUserId(userId);
				bean.setLoginPwd(pwd);
				bean.setTransPwd(transPwd);
				bean.setColor(color);
				bean.setStatus("L");
				System.out.println("before method call");
				boolean result = ibs.getRegistered(bean);
				System.out.println("after method call");
				if(result==false){
					out.println("Failed to Register User....");
				}
				else{
					out.println("Registration Successfull....");
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				ServletContext context = getServletContext();
				rd = context.getRequestDispatcher("/Error.jsp");
				rd.forward(request, response);
			}
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("fundTransfer")){
			String userId=request.getParameter("userId");
			long uid=Long.parseLong(userId);
			ArrayList<Long> GetAccounts=new ArrayList<Long>();
			ArrayList<Long> PayeeAccounts=new ArrayList<Long>();
			try{
				GetAccounts=ibs.getAccounts(uid);
				PayeeAccounts=ibs.getPayeeAccounts(uid);
				request.setAttribute("UserAccounts", GetAccounts);
				request.setAttribute("PayeeAccounts", PayeeAccounts);
				rd=request.getRequestDispatcher("/FundTransfer.jsp");
				rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			//out.println(userId);
		}
		/*else if(operation!=null&&operation.equalsIgnoreCase("getUserAccount")){
			String account=request.getParameter("accounts");
			System.out.println(account);
		}*/
		
	}	
}